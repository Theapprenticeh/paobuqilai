import ClientHeight from './ClientHeight'
export default (Vue)=>{
    Vue.component(ClientHeight.name,ClientHeight);
}