import RuleUtils from './class/RuleUtils' // 验证规则类

const common = {
  ruleUtils: RuleUtils,
}
export default common
